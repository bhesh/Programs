Brian Hession -- January 18, 2012

This is the classic game of snake. Use the arrow keys to control
the snake. Eat the red apples to raise your score but watch out
for the walls and your growing tail.

METHOD 1:
TO COMPILE AND RUN:
in the SnakeV1 directory, type:

		PATH/TO/JAVA/BIN/javac *.java
		PATH/TO/JAVA/BIN/java Driver

METHOD 2:
compile in eclipse or some other IDE.
The main class is "Driver"
